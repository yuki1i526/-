const db = require('./utils/db')

App({
  globalData: {
    userId: '',
    petId: '',
    cloudReady: false,
    // 由 write 页跳转到 journals 时用于强制刷新列表
    journalsDirty: false,
    // 详情页跳转到写日记 tab 时携带的编辑目标（switchTab 不支持带参）
    editDiaryId: ''
  },

  onLaunch() {
    db.init()
    this.globalData.userId = db.currentUserId()
    this.globalData.cloudReady = db.useCloud()
    this.ensureUser()
  },

  /** 首次使用时建立本地用户档案（对应数据字典 Users 表） */
  ensureUser() {
    const users = db.collection('Users')
    users.where({ user_id: this.globalData.userId }).get().then(res => {
      if (!res.data.length) {
        users.add({
          data: {
            user_id: this.globalData.userId,
            openid: 'local_' + this.globalData.userId,
            unionid: '',
            nickname: '日记主人',
            avatar_url: '',
            gender: 0,
            birthday: '',
            privacy_level: 1,
            remind_time: '21:30',
            notify_enabled: false,
            register_time: new Date().toISOString(),
            last_login_time: new Date().toISOString(),
            status: 1
          }
        })
      }
    })
  }
})
