const db = require('../../utils/db')

const PRESETS = {
  food: { question: '今天吃什么？', options: ['火锅', '日料', '麻辣香锅', '食堂', '螺蛳粉', '随便点外卖'] },
  play: { question: '周末去哪玩？', options: ['爬山', '看电影', '逛街', '图书馆', '公园晒太阳', '在家躺平'] },
  work: { question: '现在先做什么？', options: ['写作业', '背单词', '整理房间', '回消息', '再摸鱼十分钟'] }
}

const COLORS = ['#FFB399', '#F7C873', '#A8D8B9', '#8FC7E8', '#C4A8E8', '#F2A0B5']

Page({
  data: {
    question: PRESETS.food.question,
    options: PRESETS.food.options,
    rotating: false,
    rotateDeg: 0,
    result: '',
    showResult: false,
    history: [],
    newOption: ''
  },

  onReady() {
    db.ready().then(() => {
      this.initCanvas()
      this.loadHistory()
    })
  },

  initCanvas() {
    const query = wx.createSelectorQuery()
    query.select('#wheel').fields({ node: true, size: true }).exec(res => {
      if (!res[0]) return
      const canvas = res[0].node
      const ctx = canvas.getContext('2d')
      const info = wx.getWindowInfo ? wx.getWindowInfo() : wx.getSystemInfoSync()
      const dpr = info.pixelRatio || 2
      canvas.width = res[0].width * dpr
      canvas.height = res[0].height * dpr
      ctx.scale(dpr, dpr)
      this.canvas = canvas
      this.ctx = ctx
      this.size = res[0].width
      this.draw()
    })
  },

  draw() {
    const ctx = this.ctx
    const size = this.size
    if (!ctx) return
    const options = this.data.options
    const n = options.length
    const r = size / 2
    const seg = (Math.PI * 2) / n

    ctx.clearRect(0, 0, size, size)
    ctx.save()
    ctx.translate(r, r)

    for (let i = 0; i < n; i++) {
      const start = -Math.PI / 2 + i * seg
      const end = start + seg
      ctx.beginPath()
      ctx.moveTo(0, 0)
      ctx.arc(0, 0, r - 4, start, end)
      ctx.closePath()
      ctx.fillStyle = COLORS[i % COLORS.length]
      ctx.fill()
      ctx.strokeStyle = '#fff'
      ctx.lineWidth = 2
      ctx.stroke()

      // 文字
      ctx.save()
      ctx.rotate(start + seg / 2)
      ctx.fillStyle = '#5A4A40'
      ctx.font = 'bold ' + Math.max(12, size / 22) + 'px sans-serif'
      ctx.textAlign = 'right'
      ctx.textBaseline = 'middle'
      const label = options[i].length > 6 ? options[i].slice(0, 6) + '…' : options[i]
      ctx.fillText(label, r - 18, 0)
      ctx.restore()
    }

    // 中心圆
    ctx.beginPath()
    ctx.arc(0, 0, 26, 0, Math.PI * 2)
    ctx.fillStyle = '#fff'
    ctx.fill()
    ctx.restore()
  },

  onQuestion(e) {
    this.setData({ question: e.detail.value })
  },

  usePreset(e) {
    const key = e.currentTarget.dataset.key
    const p = PRESETS[key]
    this.setData({ question: p.question, options: p.options.slice(), result: '', showResult: false })
    this.draw()
  },

  onNewOption(e) {
    this.setData({ newOption: e.detail.value })
  },

  addOption() {
    const v = (this.data.newOption || '').trim()
    if (!v) return
    if (this.data.options.length >= 8) {
      wx.showToast({ title: '最多 8 个选项', icon: 'none' })
      return
    }
    this.setData({ options: this.data.options.concat([v]), newOption: '' })
    this.draw()
  },

  removeOption(e) {
    const idx = e.currentTarget.dataset.idx
    if (this.data.options.length <= 2) {
      wx.showToast({ title: '至少保留 2 个选项', icon: 'none' })
      return
    }
    const list = this.data.options.slice()
    list.splice(idx, 1)
    this.setData({ options: list })
    this.draw()
  },

  spin() {
    if (this.data.rotating) return
    if (this.data.options.length < 2) {
      wx.showToast({ title: '至少需要 2 个选项', icon: 'none' })
      return
    }
    const n = this.data.options.length
    const seg = 360 / n
    const idx = Math.floor(Math.random() * n)

    const want = (((-idx * seg - seg / 2) % 360) + 360) % 360
    const cur = (((this.curRot || 0) % 360) + 360) % 360
    const delta = (((want - cur) % 360) + 360) % 360
    this.curRot = (this.curRot || 0) + 360 * 5 + delta

    this.setData({ rotating: true, showResult: false, rotateDeg: this.curRot })
    wx.vibrateShort({ type: 'medium' })

    setTimeout(() => {
      const pick = this.data.options[idx]
      this.setData({ rotating: false, showResult: true, result: pick })
      this.saveRecord(pick)
    }, 3200)
  },

  async saveRecord(pick) {
    const uid = db.currentUserId()
    await db.collection('RandomDecisions').add({
      data: {
        decision_id: db.uid(),
        user_id: uid,
        question: this.data.question,
        options: JSON.stringify(this.data.options),
        result_option: pick,
        scene: 'food',
        is_favorite: false,
        decide_time: new Date().toISOString()
      }
    })
    this.loadHistory()
  },

  async loadHistory() {
    const res = await db.collection('RandomDecisions')
      .where({ user_id: db.currentUserId() })
      .orderBy('decide_time', 'desc')
      .limit(5)
      .get()
    this.setData({
      history: res.data.map(h => ({
        id: h.decision_id,
        question: h.question,
        result: h.result_option,
        time: (h.decide_time || '').replace('T', ' ').slice(5, 16)
      }))
    })
  },

  closeResult() {
    this.setData({ showResult: false })
  }
})
