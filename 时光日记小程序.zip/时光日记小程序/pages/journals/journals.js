const db = require('../../utils/db')
const util = require('../../utils/util')

Page({
  data: {
    keyword: '',
    categories: [],
    categoryId: '',
    onlyFav: false,
    groups: [],
    total: 0,
    loading: true
  },

  onShow() {
    db.ready().then(() => {
      this.loadCategories()
      this.load()
    })
  },

  onPullDownRefresh() {
    this.load().then(() => wx.stopPullDownRefresh())
  },

  async loadCategories() {
    const res = await db.collection('Categories')
      .where({ user_id: db.currentUserId() })
      .orderBy('sort_order', 'asc')
      .get()
    const cats = res.data
    const stats = await Promise.all(cats.map(c =>
      db.collection('Diaries').where({ user_id: db.currentUserId(), category_id: c.category_id, status: 1 }).get()
    ))
    this.setData({
      categories: cats.map((c, i) => Object.assign({}, c, { count: stats[i].data.length }))
    })
  },

  async load() {
    const uid = db.currentUserId()
    const cond = { user_id: uid, status: 1 }
    if (this.data.categoryId) cond.category_id = this.data.categoryId
    if (this.data.onlyFav) cond.is_favorite = true

    const res = await db.collection('Diaries').where(cond).orderBy('diary_date', 'desc').get()
    const kw = this.data.keyword.trim().toLowerCase()
    const list = res.data
      .filter(d => !kw || (d.title || '').toLowerCase().indexOf(kw) >= 0 || (d.content || '').toLowerCase().indexOf(kw) >= 0)
      .sort((a, b) => (a.diary_date < b.diary_date ? 1 : a.diary_date > b.diary_date ? -1 : 0))

    const groups = []
    const index = {}
    list.forEach(d => {
      const key = d.diary_date || '未知'
      if (index[key] === undefined) {
        index[key] = groups.length
        groups.push({ key, label: util.relLabel(key), items: [] })
      }
      const mood = util.moodOf(d.mood)
      groups[index[key]].items.push({
        diary_id: d.diary_id,
        title: d.title || '无标题',
        excerpt: (d.content || '').replace(/\n/g, ' '),
        moodEmoji: mood.emoji,
        moodColor: mood.color,
        weatherEmoji: util.weatherOf(d.weather).emoji,
        wordCount: d.word_count || 0,
        is_favorite: d.is_favorite,
        is_draft: d.is_draft,
        timeText: (d.created_at || '').slice(11, 16)
      })
    })

    this.setData({ groups, total: list.length, loading: false })
  },

  onSearch(e) {
    this.setData({ keyword: e.detail.value })
    if (this._t) clearTimeout(this._t)
    this._t = setTimeout(() => this.load(), 250)
  },

  clearSearch() {
    this.setData({ keyword: '' })
    this.load()
  },

  pickCategory(e) {
    const id = e.currentTarget.dataset.id
    this.setData({ categoryId: this.data.categoryId === id ? '' : id })
    this.load()
  },

  toggleFav() {
    this.setData({ onlyFav: !this.data.onlyFav })
    this.load()
  },

  goDetail(e) {
    wx.navigateTo({ url: '/pages/detail/detail?id=' + e.currentTarget.dataset.id })
  },

  onLongPress(e) {
    const id = e.currentTarget.dataset.id
    const fav = e.currentTarget.dataset.fav
    wx.showActionSheet({
      itemList: [fav ? '取消收藏' : '收藏', '删除'],
      success: async r => {
        if (r.tapIndex === 0) {
          await db.collection('Diaries').where({ diary_id: id }).update({ data: { is_favorite: !fav } })
          this.load()
          wx.showToast({ title: fav ? '已取消收藏' : '已收藏', icon: 'none' })
        } else if (r.tapIndex === 1) {
          wx.showModal({
            title: '删除这篇日记？',
            content: '删除后无法恢复',
            confirmColor: '#E85F3D',
            success: async m => {
              if (m.confirm) {
                await db.collection('Diaries').where({ diary_id: id }).update({ data: { status: 0 } })
                this.load()
                this.loadCategories()
                wx.showToast({ title: '已删除', icon: 'none' })
              }
            }
          })
        }
      }
    })
  },

  goWrite() {
    wx.switchTab({ url: '/pages/write/write' })
  }
})
