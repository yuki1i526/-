const db = require('../../utils/db')
const service = require('../../utils/service')
const util = require('../../utils/util')

Page({
  data: {
    diary: null,
    media: [],
    dateText: '',
    mood: null,
    weather: null,
    categoryName: '',
    paragraphs: [],
    loading: true
  },

  onLoad(options) {
    this.diaryId = options.id
    db.ready().then(() => this.load())
  },

  onShow() {
    if (this.diaryId && this.data.diary) this.load()
  },

  async load() {
    const res = await db.collection('Diaries').where({ diary_id: this.diaryId }).get()
    if (!res.data.length) {
      wx.showToast({ title: '日记不存在', icon: 'none' })
      setTimeout(() => wx.navigateBack(), 800)
      return
    }
    const d = res.data[0]
    const [mediaRes, catRes] = await Promise.all([
      db.collection('DiaryMedia').where({ diary_id: this.diaryId }).orderBy('sort_order', 'asc').get(),
      d.category_id ? db.collection('Categories').where({ category_id: d.category_id }).get() : Promise.resolve({ data: [] })
    ])

    this.setData({
      diary: d,
      media: mediaRes.data,
      mood: util.moodOf(d.mood),
      weather: util.weatherOf(d.weather),
      dateText: util.prettyDate(d.diary_date),
      categoryName: catRes.data.length ? catRes.data[0].name : '',
      paragraphs: (d.content || '').split('\n').filter(p => p.trim() !== ''),
      loading: false
    })
    wx.setNavigationBarTitle({ title: d.title || '日记' })
  },

  toggleFav() {
    const v = !this.data.diary.is_favorite
    db.collection('Diaries').where({ diary_id: this.diaryId }).update({ data: { is_favorite: v } })
      .then(() => {
        this.setData({ 'diary.is_favorite': v })
        wx.showToast({ title: v ? '已收藏' : '已取消收藏', icon: 'none' })
      })
  },

  edit() {
    getApp().globalData.editDiaryId = this.diaryId
    wx.switchTab({ url: '/pages/write/write' })
  },

  remove() {
    wx.showModal({
      title: '删除这篇日记？',
      content: '删除后无法恢复',
      confirmColor: '#E85F3D',
      success: async res => {
        if (res.confirm) {
          await db.collection('Diaries').where({ diary_id: this.diaryId }).update({ data: { status: 0 } })
          getApp().globalData.journalsDirty = true
          wx.showToast({ title: '已删除', icon: 'none' })
          setTimeout(() => wx.navigateBack(), 600)
        }
      }
    })
  },

  previewMedia(e) {
    const idx = e.currentTarget.dataset.idx
    wx.previewImage({
      current: this.data.media[idx].file_id,
      urls: this.data.media.map(m => m.file_id)
    })
  }
})
