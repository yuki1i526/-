const db = require('../../utils/db')
const util = require('../../utils/util')

function oneYearLater() {
  const d = new Date()
  d.setFullYear(d.getFullYear() + 1)
  return util.formatDate(d)
}

Page({
  data: {
    tab: 0,
    list: [],
    visible: [],
    loading: true,
    showEditor: false,
    form: { title: '', content: '', openDate: '' },
    viewing: null
  },

  onLoad() {
    this.setData({ 'form.openDate': oneYearLater() })
    db.ready().then(() => this.load())
  },

  onShow() {
    if (!this.data.loading) this.load()
  },

  async load() {
    const res = await db.collection('TimeCapsules')
      .where({ user_id: db.currentUserId() })
      .orderBy('open_time', 'asc')
      .get()
    const now = Date.now()
    const list = res.data.map(c => {
      const t = new Date(String(c.open_time).replace(/-/g, '/')).getTime()
      const due = t <= now
      const days = due ? 0 : Math.ceil((t - now) / 86400000)
      return Object.assign({}, c, {
        due,
        days,
        openText: util.formatDate(c.open_time),
        createText: (c.created_at || '').slice(0, 10),
        preview: (c.content || '').slice(0, 40)
      })
    })
    this.setData({ list, visible: this.applyFilter(list, this.data.tab), loading: false })
  },

  applyFilter(list, tab) {
    return tab === 0 ? list.filter(c => !c.due) : list.filter(c => c.due)
  },

  filter(e) {
    const tab = Number(e.currentTarget.dataset.tab)
    this.setData({ tab, visible: this.applyFilter(this.data.list, tab) })
  },

  openEditor() {
    this.setData({
      showEditor: true,
      form: { title: '', content: '', openDate: oneYearLater() }
    })
  },

  closeEditor() {
    this.setData({ showEditor: false })
  },

  onTitle(e) {
    this.setData({ 'form.title': e.detail.value })
  },

  onContent(e) {
    this.setData({ 'form.content': e.detail.value })
  },

  onDate(e) {
    this.setData({ 'form.openDate': e.detail.value })
  },

  async save() {
    const f = this.data.form
    if (!f.content.trim()) {
      wx.showToast({ title: '写点内容再封存吧', icon: 'none' })
      return
    }
    if (!f.openDate || util.daysUntil(f.openDate) <= 0) {
      wx.showToast({ title: '开启时间要晚于今天', icon: 'none' })
      return
    }
    wx.showLoading({ title: '封存中', mask: true })
    await db.collection('TimeCapsules').add({
      data: {
        capsule_id: db.uid(),
        user_id: db.currentUserId(),
        title: f.title || '给未来的信',
        content: f.content,
        media_list: '[]',
        open_time: f.openDate + ' 09:00',
        status: 1,
        is_notified: false,
        created_at: new Date().toISOString()
      }
    })
    wx.hideLoading()
    this.setData({ showEditor: false })
    wx.showToast({ title: '已封存，等待未来开封', icon: 'none' })
    this.load()
  },

  tapCapsule(e) {
    const idx = e.currentTarget.dataset.idx
    const c = this.data.visible[idx]
    if (!c.due) {
      wx.showToast({ title: '还有 ' + c.days + ' 天才能开启', icon: 'none' })
      return
    }
    this.setData({
      viewing: Object.assign({}, c, {
        paragraphs: (c.content || '').split('\n').filter(p => p.trim() !== '')
      })
    })
    if (c.status === 1) {
      db.collection('TimeCapsules').where({ capsule_id: c.capsule_id }).update({ data: { status: 2 } })
    }
  },

  closeView() {
    this.setData({ viewing: null })
    this.load()
  },

  removeCapsule(e) {
    const id = e.currentTarget.dataset.id
    wx.showModal({
      title: '删除这封信？',
      content: '删除后无法找回',
      confirmColor: '#E85F3D',
      success: async r => {
        if (r.confirm) {
          await db.collection('TimeCapsules').where({ capsule_id: id }).remove()
          this.load()
        }
      }
    })
  }
})
