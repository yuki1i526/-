const db = require('../../utils/db')
const service = require('../../utils/service')

const COND_TEXT = {
  diary_count: '写满 {v} 篇日记',
  continuous_days: '连续记录 {v} 天',
  word_count: '累计写下 {v} 字',
  favorite_count: '收藏 {v} 篇日记'
}

Page({
  data: {
    list: [],
    unlocked: 0,
    total: 0,
    loading: true
  },

  onLoad() {
    db.ready().then(() => this.load())
  },

  async load() {
    const list = await service.getBadgeProgress()
    const view = list.map(b => ({
      badge_id: b.badge_id,
      name: b.name,
      icon: b.icon_url,
      level: b.badge_level,
      levelText: ['', '铜', '银', '金'][b.badge_level] || '',
      desc: b.description,
      condition: (COND_TEXT[b.condition_type] || '').replace('{v}', b.condition_value),
      current: b.current,
      target: b.condition_value,
      percent: b.percent,
      unlocked: b.unlocked
    }))
    this.setData({
      list: view,
      unlocked: view.filter(v => v.unlocked).length,
      total: view.length,
      loading: false
    })
  },

  back() {
    wx.navigateBack()
  }
})
