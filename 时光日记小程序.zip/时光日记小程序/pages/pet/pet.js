const db = require('../../utils/db')
const service = require('../../utils/service')
const util = require('../../utils/util')

Page({
  data: {
    pet: null,
    level: { level: 1, cur: 0, need: 100, percent: 0 },
    petStatus: '',
    foods: [],
    feeds: [],
    petEmoji: '🐱',
    feeding: false
  },

  onLoad() {
    db.ready().then(() => this.load())
  },

  async load() {
    const [pet, foodRes, feedRes] = await Promise.all([
      service.getPet(),
      db.collection('FoodItems').where({ is_active: true }).get(),
      db.collection('FeedLogs').where({ user_id: db.currentUserId() }).orderBy('feed_time', 'desc').limit(10).get()
    ])
    const level = util.levelOf(pet.exp || 0)
    const foods = foodRes.data

    const feeds = feedRes.data.map(f => {
      const food = foods.filter(x => x.food_id === f.food_id)[0]
      return {
        feed_id: f.feed_id,
        text: f.feed_type === 'write_diary' ? '写日记获得奖励' : '投喂了 ' + (food ? food.name : '食物'),
        exp: f.exp_gain,
        time: (f.feed_time || '').replace('T', ' ').slice(5, 16)
      }
    })

    this.setData({
      pet,
      level,
      foods,
      feeds,
      petEmoji: pet.pet_type === '狗' ? '🐶' : '🐱',
      petStatus: this.statusText(pet)
    })
  },

  statusText(pet) {
    const h = pet.hunger || 0
    if (h < 25) return '饿了，喵喵叫'
    if (h < 50) return '有点饿，蹭了蹭你'
    if ((pet.intimacy || 0) > 70) return '趴在你腿上不想动'
    if (h > 85) return '吃太饱了，正在打滚'
    return '心情不错，在窗边晒太阳'
  },

  async onFeed(e) {
    if (this.data.feeding) return
    const idx = e.currentTarget.dataset.idx
    const food = this.data.foods[idx]
    this.setData({ feeding: true })
    wx.vibrateShort({ type: 'light' })
    try {
      await service.feedPet(food)
      wx.showToast({ title: '＋' + food.exp_value + ' 经验', icon: 'none' })
      await this.load()
    } finally {
      setTimeout(() => this.setData({ feeding: false }), 300)
    }
  },

  rename() {
    wx.showModal({
      title: '给宠物改名',
      editable: true,
      placeholderText: '输入新名字',
      content: this.data.pet.pet_name,
      success: async res => {
        if (res.confirm && (res.content || '').trim()) {
          await service.renamePet(res.content.trim())
          this.load()
        }
      }
    })
  },

  changeType() {
    wx.showActionSheet({
      itemList: ['猫', '狗', '兔子'],
      success: async r => {
        const types = ['猫', '狗', '兔子']
        await db.collection('Pets').where({ pet_id: this.data.pet.pet_id })
          .update({ data: { pet_type: types[r.tapIndex] } })
        this.load()
      }
    })
  },

  goBadges() {
    wx.navigateTo({ url: '/pages/badges/badges' })
  }
})
