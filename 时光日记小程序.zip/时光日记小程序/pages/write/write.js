const db = require('../../utils/db')
const service = require('../../utils/service')
const util = require('../../utils/util')

const DRAFT_KEY = 'td_draft'

Page({
  data: {
    editing: false,
    diaryId: '',
    diaryDate: '',
    title: '',
    content: '',
    wordCount: 0,
    mood: '',
    weather: '',
    location: '',
    categoryId: '',
    categories: [],
    moods: util.MOODS,
    weathers: util.WEATHERS,
    media: [],
    saving: false,
    draftTip: ''
  },

  onLoad(options) {
    this.setData({
      diaryDate: util.todayStr(),
      weather: '',
      mood: ''
    })
    db.ready().then(() => {
      this.loadCategories()
      if (options && options.id) {
        this.loadDiary(options.id)
      } else {
        this.restoreDraft()
      }
    })
  },

  onShow() {
    const app = getApp()
    if (app.globalData.editDiaryId) {
      const id = app.globalData.editDiaryId
      app.globalData.editDiaryId = ''
      this.loadDiary(id)
      return
    }
    if (!this.data.editing && !this.data.diaryId) {
      this.setData({ diaryDate: util.todayStr() })
    }
  },

  async loadCategories() {
    const res = await db.collection('Categories')
      .where({ user_id: db.currentUserId() })
      .orderBy('sort_order', 'asc')
      .get()
    this.setData({ categories: res.data })
  },

  async loadDiary(id) {
    const res = await db.collection('Diaries').where({ diary_id: id }).get()
    if (!res.data.length) return
    const d = res.data[0]
    this.setData({
      editing: true,
      diaryId: d.diary_id,
      title: d.title || '',
      content: d.content || '',
      wordCount: d.word_count || util.wordCount(d.content),
      mood: d.mood || '',
      weather: d.weather || '',
      location: d.location || '',
      categoryId: d.category_id || '',
      diaryDate: d.diary_date || util.todayStr()
    })
    const media = await db.collection('DiaryMedia').where({ diary_id: id }).orderBy('sort_order', 'asc').get()
    this.setData({
      media: media.data.map(m => ({ path: m.file_id, type: m.media_type, fileID: m.file_id }))
    })
  },

  /* ---------- 草稿 ---------- */
  restoreDraft() {
    const d = wx.getStorageSync(DRAFT_KEY)
    if (d && (d.content || d.title)) {
      this.setData({
        title: d.title || '',
        content: d.content || '',
        wordCount: util.wordCount(d.content),
        mood: d.mood || '',
        weather: d.weather || '',
        categoryId: d.categoryId || '',
        media: d.media || [],
        draftTip: '已恢复上次编辑的草稿'
      })
      setTimeout(() => this.setData({ draftTip: '' }), 3000)
    }
  },

  autoSaveDraft() {
    if (this.data.editing) return
    const { title, content, mood, weather, categoryId, media } = this.data
    if (!title && !content && !media.length) return
    wx.setStorageSync(DRAFT_KEY, { title, content, mood, weather, categoryId, media, ts: Date.now() })
  },

  clearDraft() {
    wx.removeStorageSync(DRAFT_KEY)
  },

  /* ---------- 表单 ---------- */
  onTitle(e) {
    this.setData({ title: e.detail.value })
    this.debounceDraft()
  },

  onContent(e) {
    const v = e.detail.value
    this.setData({ content: v, wordCount: util.wordCount(v) })
    this.debounceDraft()
  },

  debounceDraft() {
    if (this._timer) clearTimeout(this._timer)
    this._timer = setTimeout(() => this.autoSaveDraft(), 1500)
  },

  onDateChange(e) {
    this.setData({ diaryDate: e.detail.value })
  },

  pickMood(e) {
    const key = e.currentTarget.dataset.key
    this.setData({ mood: this.data.mood === key ? '' : key })
    this.debounceDraft()
  },

  pickWeather(e) {
    const key = e.currentTarget.dataset.key
    this.setData({ weather: this.data.weather === key ? '' : key })
    this.debounceDraft()
  },

  pickCategory(e) {
    const id = e.currentTarget.dataset.id
    this.setData({ categoryId: this.data.categoryId === id ? '' : id })
    this.debounceDraft()
  },

  onLocation() {
    wx.chooseLocation({
      success: res => {
        this.setData({ location: res.name || res.address || '' })
        this.debounceDraft()
      },
      fail: () => {
        wx.showToast({ title: '未获取到位置', icon: 'none' })
      }
    })
  },

  clearLocation() {
    this.setData({ location: '' })
  },

  /* ---------- 媒体 ---------- */
  chooseMedia() {
    const left = 9 - this.data.media.length
    if (left <= 0) {
      wx.showToast({ title: '最多 9 张', icon: 'none' })
      return
    }
    wx.chooseMedia({
      count: left,
      mediaType: ['image'],
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: res => {
        const add = res.tempFiles.map(f => ({ path: f.tempFilePath, type: 'image', size: f.size, fileID: '' }))
        this.setData({ media: this.data.media.concat(add) })
        this.debounceDraft()
      }
    })
  },

  previewMedia(e) {
    const idx = e.currentTarget.dataset.idx
    wx.previewImage({
      current: this.data.media[idx].path,
      urls: this.data.media.map(m => m.path)
    })
  },

  removeMedia(e) {
    const idx = e.currentTarget.dataset.idx
    const list = this.data.media.slice()
    list.splice(idx, 1)
    this.setData({ media: list })
    this.debounceDraft()
  },

  /* ---------- 保存 ---------- */
  async onSaveDraft() {
    if (!this.data.content && !this.data.title && !this.data.media.length) {
      wx.showToast({ title: '还没有内容', icon: 'none' })
      return
    }
    this.setData({ saving: true })
    try {
      await service.saveDiary({
        diary_id: this.data.diaryId,
        title: this.data.title,
        content: this.data.content,
        mood: this.data.mood,
        weather: this.data.weather,
        location: this.data.location,
        category_id: this.data.categoryId,
        diary_date: this.data.diaryDate,
        is_draft: true,
        mediaList: this.data.media
      })
      this.clearDraft()
      wx.showToast({ title: '已存为草稿', icon: 'success' })
      this.resetForm()
      setTimeout(() => wx.switchTab({ url: '/pages/journals/journals' }), 600)
    } catch (e) {
      console.error(e)
      wx.showToast({ title: '保存失败', icon: 'none' })
    } finally {
      this.setData({ saving: false })
    }
  },

  async onPublish() {
    if (!this.data.content.trim()) {
      wx.showToast({ title: '写点什么再发布吧', icon: 'none' })
      return
    }
    this.setData({ saving: true })
    wx.showLoading({ title: '保存中', mask: true })
    try {
      const res = await service.saveDiary({
        diary_id: this.data.diaryId,
        title: this.data.title || '无标题',
        content: this.data.content,
        mood: this.data.mood,
        weather: this.data.weather,
        location: this.data.location,
        category_id: this.data.categoryId,
        diary_date: this.data.diaryDate,
        is_draft: false,
        mediaList: this.data.media
      })
      this.clearDraft()
      wx.hideLoading()

      if (!this.data.editing) {
        const fresh = res.unlocked || []
        if (fresh.length) {
          wx.showModal({
            title: '解锁新徽章',
            content: fresh.map(b => b.icon_url + ' ' + b.name).join('\n'),
            showCancel: false,
            confirmText: '好耶'
          })
        } else {
          wx.showToast({ title: '已记录，团子长大了一点', icon: 'none' })
        }
      } else {
        wx.showToast({ title: '已更新', icon: 'success' })
      }

      getApp().globalData.journalsDirty = true
      this.resetForm()
      setTimeout(() => wx.switchTab({ url: '/pages/journals/journals' }), 700)
    } catch (e) {
      console.error(e)
      wx.hideLoading()
      wx.showToast({ title: '保存失败，请重试', icon: 'none' })
    } finally {
      this.setData({ saving: false })
    }
  },

  resetForm() {
    this.setData({
      editing: false,
      diaryId: '',
      title: '',
      content: '',
      wordCount: 0,
      mood: '',
      weather: '',
      location: '',
      categoryId: '',
      media: [],
      diaryDate: util.todayStr()
    })
  }
})
