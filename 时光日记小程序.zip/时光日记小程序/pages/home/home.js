const db = require('../../utils/db')
const service = require('../../utils/service')
const util = require('../../utils/util')

Page({
  data: {
    greeting: '',
    dateText: '',
    nickname: '',
    pet: null,
    petLevel: { level: 1, percent: 0, cur: 0, need: 100 },
    petMood: '今天也辛苦啦',
    petType: '猫',
    todayDone: false,
    continuous: 0,
    countdowns: [],
    recent: [],
    stats: { diaryCount: 0, totalWords: 0 },
    loading: true
  },

  onShow() {
    this.setData({ greeting: util.greeting(), dateText: util.prettyDate(util.todayStr()) })
    db.ready().then(() => this.load())
  },

  onPullDownRefresh() {
    this.load().then(() => wx.stopPullDownRefresh())
  },

  async load() {
    const uid = db.currentUserId()
    try {
      const [pet, todayCheck, checks, cdRes, recentRes, stats, userRes] = await Promise.all([
        service.getPet(),
        db.collection('CheckIns').where({ user_id: uid, checkin_date: util.todayStr() }).get(),
        db.collection('CheckIns').where({ user_id: uid }).orderBy('checkin_date', 'desc').limit(1).get(),
        db.collection('CountdownEvents').where({ user_id: uid, status: 1 }).get(),
        db.collection('Diaries').where({ user_id: uid, status: 1, is_draft: false }).orderBy('diary_date', 'desc').limit(2).get(),
        service.getStats(),
        db.collection('Users').where({ user_id: uid }).get()
      ])

      const countdowns = cdRes.data
        .map(c => {
          const days = util.daysUntil(c.target_date)
          return Object.assign({}, c, {
            days,
            daysText: days === 0 ? '就是今天' : (days > 0 ? days + ' 天' : '已过去 ' + Math.abs(days) + ' 天'),
            dateText: util.formatDate(c.target_date),
            bg: this.gradientOf(c.theme_color)
          })
        })
        .sort((a, b) => (a.days < 0 ? 1 : 0) - (b.days < 0 ? 1 : 0) || a.days - b.days)

      const recent = recentRes.data.map(d => ({
        diary_id: d.diary_id,
        title: d.title || '无标题',
        excerpt: (d.content || '').replace(/\n/g, ' '),
        dateText: util.relLabel(d.diary_date),
        moodEmoji: util.moodOf(d.mood).emoji,
        weatherEmoji: util.weatherOf(d.weather).emoji,
        wordCount: d.word_count || 0,
        is_favorite: d.is_favorite
      }))

      this.setData({
        pet,
        petLevel: util.levelOf(pet.exp || 0),
        petMood: this.moodText(pet),
        petType: pet.pet_type || '猫',
        todayDone: todayCheck.data.length > 0,
        continuous: checks.data.length ? checks.data[0].continuous_days || 0 : 0,
        countdowns,
        recent,
        stats: { diaryCount: stats.diaryCount, totalWords: stats.totalWords },
        nickname: userRes.data.length ? (userRes.data[0].nickname || '日记主人') : '日记主人',
        loading: false
      })
    } catch (e) {
      console.error(e)
      this.setData({ loading: false })
    }
  },

  moodText(pet) {
    if (!pet) return '今天也辛苦啦'
    const h = pet.hunger || 0
    if (h < 25) return '肚子好饿…'
    if (h < 50) return '有点想吃东西'
    if ((pet.intimacy || 0) > 70) return '最喜欢你了'
    return '今天也辛苦啦'
  },

  gradientOf(color) {
    const c = color || '#FF7A59'
    return 'linear-gradient(135deg, ' + c + ', ' + this.lighten(c) + ')'
  },

  lighten(hex) {
    const h = hex.replace('#', '')
    const r = Math.min(255, parseInt(h.slice(0, 2), 16) + 46)
    const g = Math.min(255, parseInt(h.slice(2, 4), 16) + 40)
    const b = Math.min(255, parseInt(h.slice(4, 6), 16) + 34)
    return 'rgb(' + r + ',' + g + ',' + b + ')'
  },

  /* ---------- 交互 ---------- */
  goWrite() {
    wx.switchTab({ url: '/pages/write/write' })
  },

  onTodayTap() {
    if (this.data.todayDone) this.goJournals()
    else this.goWrite()
  },

  goJournals() {
    wx.switchTab({ url: '/pages/journals/journals' })
  },

  goDetail(e) {
    wx.navigateTo({ url: '/pages/detail/detail?id=' + e.currentTarget.dataset.id })
  },

  goDecide() {
    wx.navigateTo({ url: '/pages/decide/decide' })
  },

  goCapsule() {
    wx.navigateTo({ url: '/pages/capsule/capsule' })
  },

  goBadges() {
    wx.navigateTo({ url: '/pages/badges/badges' })
  },

  goPet() {
    wx.navigateTo({ url: '/pages/pet/pet' })
  },

  async onFeed() {
    const res = await db.collection('FoodItems').where({ is_active: true }).get()
    const foods = res.data
    if (!foods.length) return
    wx.showActionSheet({
      itemList: foods.map(f => f.icon_url + ' ' + f.name + '  +' + f.exp_value + '经验'),
      success: async r => {
        const food = foods[r.tapIndex]
        wx.showLoading({ title: '投喂中', mask: true })
        try {
          await service.feedPet(food)
          wx.hideLoading()
          wx.vibrateShort({ type: 'light' })
          wx.showToast({ title: '团子吃得很开心', icon: 'none' })
          this.load()
        } catch (err) {
          wx.hideLoading()
          wx.showToast({ title: '投喂失败', icon: 'none' })
        }
      }
    })
  }
})
