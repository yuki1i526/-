const db = require('../../utils/db')
const service = require('../../utils/service')
const util = require('../../utils/util')

const PRIVACY = ['仅保存在本机', '云端加密存储', '云端明文存储']

Page({
  data: {
    user: null,
    nickname: '日记主人',
    joinDays: 1,
    stats: { diaryCount: 0, totalWords: 0, continuous: 0, badgeCount: 0, badgeTotal: 0 },
    pet: null,
    petLevel: { level: 1, percent: 0 },
    favCount: 0,
    capsuleCount: 0,
    cloudMode: false,
    privacyText: '',
    remindTime: '21:30'
  },

  onShow() {
    db.ready().then(() => this.load())
  },

  async load() {
    const uid = db.currentUserId()
    const [users, stats, favs, capsules] = await Promise.all([
      db.collection('Users').where({ user_id: uid }).get(),
      service.getStats(),
      db.collection('Diaries').where({ user_id: uid, is_favorite: true, status: 1 }).get(),
      db.collection('TimeCapsules').where({ user_id: uid }).get()
    ])
    const user = users.data[0] || null
    const joinDays = user && user.register_time ? Math.max(1, util.dayDiff(util.todayStr(), user.register_time) + 1) : 1

    this.setData({
      user,
      nickname: user ? user.nickname || '日记主人' : '日记主人',
      joinDays,
      stats,
      pet: stats.pet,
      petLevel: util.levelOf(stats.pet.exp || 0),
      favCount: favs.data.length,
      capsuleCount: capsules.data.length,
      cloudMode: db.useCloud(),
      privacyText: user ? PRIVACY[user.privacy_level] || PRIVACY[1] : PRIVACY[1],
      remindTime: user ? user.remind_time || '21:30' : '21:30'
    })
  },

  editNickname() {
    wx.showModal({
      title: '修改昵称',
      editable: true,
      placeholderText: '输入新的昵称',
      content: this.data.nickname,
      success: async res => {
        if (res.confirm && res.content && res.content.trim()) {
          await db.collection('Users').where({ user_id: db.currentUserId() })
            .update({ data: { nickname: res.content.trim() } })
          this.load()
        }
      }
    })
  },

  changeRemind() {
    wx.showModal({
      title: '每日提醒时间',
      editable: true,
      placeholderText: '例如 21:30',
      content: this.data.remindTime,
      success: async res => {
        if (res.confirm && /^\d{1,2}:\d{2}$/.test((res.content || '').trim())) {
          await db.collection('Users').where({ user_id: db.currentUserId() })
            .update({ data: { remind_time: res.content.trim() } })
          this.load()
          wx.showToast({ title: '已设置', icon: 'none' })
        } else if (res.confirm) {
          wx.showToast({ title: '格式应为 21:30', icon: 'none' })
        }
      }
    })
  },

  changePrivacy() {
    wx.showActionSheet({
      itemList: PRIVACY,
      success: async r => {
        await db.collection('Users').where({ user_id: db.currentUserId() })
          .update({ data: { privacy_level: r.tapIndex } })
        this.load()
        wx.showToast({ title: '已切换为' + PRIVACY[r.tapIndex], icon: 'none' })
      }
    })
  },

  goFav() {
    wx.switchTab({ url: '/pages/journals/journals' })
    wx.showToast({ title: '点右上角 ☆ 只看收藏', icon: 'none' })
  },

  goBadges() {
    wx.navigateTo({ url: '/pages/badges/badges' })
  },

  goCapsule() {
    wx.navigateTo({ url: '/pages/capsule/capsule' })
  },

  goPet() {
    wx.navigateTo({ url: '/pages/pet/pet' })
  },

  goDecide() {
    wx.navigateTo({ url: '/pages/decide/decide' })
  },

  exportData() {
    const uid = db.currentUserId()
    db.collection('Diaries').where({ user_id: uid, status: 1 }).get().then(res => {
      const text = res.data
        .map(d => '【' + d.diary_date + '】' + (d.title || '') + '\n' + (d.content || ''))
        .join('\n\n────────\n\n')
      wx.setClipboardData({
        data: text || '还没有日记可以导出',
        success: () => wx.showToast({ title: '已复制到剪贴板', icon: 'none' })
      })
    })
  },

  resetData() {
    wx.showModal({
      title: '清空所有数据？',
      content: '这会删除本机的全部日记、宠物与徽章记录，并恢复为初始演示数据。',
      confirmText: '清空',
      confirmColor: '#E85F3D',
      success: res => {
        if (res.confirm) {
          db.resetAll()
          wx.showToast({ title: '已重置', icon: 'success' })
          setTimeout(() => this.load(), 500)
        }
      }
    })
  },

  about() {
    wx.showModal({
      title: '关于时光日记',
      content: '版本 1.0.0\n第十五组 · 林欣然、胡馨文\n记录 + 隐私 + AI + 游戏化',
      showCancel: false
    })
  }
})
