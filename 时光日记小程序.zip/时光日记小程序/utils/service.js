/** 业务服务层：把「写日记 → 打卡 → 宠物成长 → 徽章解锁」这条链路收在一处 */
const db = require('./db')
const { uuid, todayStr, formatDate, dayDiff, wordCount } = require('./util')

const uid = () => db.currentUserId()

/* ---------------- 宠物 ---------------- */
async function getPet() {
  const res = await db.collection('Pets').where({ user_id: uid() }).get()
  if (res.data.length) return res.data[0]
  const pet = {
    pet_id: 'pet_' + uuid().slice(0, 8),
    user_id: uid(),
    pet_name: '团子',
    pet_type: '猫',
    skin_id: 'default',
    level: 1,
    exp: 0,
    hunger: 60,
    intimacy: 0,
    status: 1,
    last_feed_time: '',
    created_at: new Date().toISOString()
  }
  await db.collection('Pets').add({ data: pet })
  return pet
}

async function renamePet(name) {
  const pet = await getPet()
  await db.collection('Pets').where({ pet_id: pet.pet_id }).update({ data: { pet_name: name } })
}

/** 喂食：扣币（本地版不记账）+ 加经验 + 加饱腹 + 加亲密度 */
async function feedPet(food) {
  const pet = await getPet()
  const hunger = Math.min(100, (pet.hunger || 0) + (food.hunger_value || 0))
  const exp = (pet.exp || 0) + (food.exp_value || 0)
  const intimacy = Math.min(100, (pet.intimacy || 0) + 2)
  const now = new Date().toISOString()

  await db.collection('Pets').where({ pet_id: pet.pet_id }).update({
    data: { hunger, exp, intimacy, status: hunger < 30 ? 2 : 1, last_feed_time: now }
  })
  await db.collection('FeedLogs').add({
    data: {
      feed_id: uuid(),
      pet_id: pet.pet_id,
      user_id: uid(),
      diary_id: '',
      food_id: food.food_id,
      feed_type: 'manual',
      exp_gain: food.exp_value || 0,
      hunger_after: hunger,
      feed_time: now
    }
  })
  return { hunger, exp, intimacy }
}

/* ---------------- 打卡 ---------------- */
async function latestCheckin() {
  const res = await db.collection('CheckIns')
    .where({ user_id: uid() })
    .orderBy('checkin_date', 'desc')
    .limit(1)
    .get()
  return res.data[0] || null
}

async function checkinToday(diaryId) {
  const today = todayStr()
  const exist = await db.collection('CheckIns').where({ user_id: uid(), checkin_date: today }).get()
  if (exist.data.length) return exist.data[0]

  const last = await latestCheckin()
  let continuous = 1
  if (last && last.checkin_date) {
    const gap = dayDiff(today, last.checkin_date)
    if (gap === 1) continuous = (last.continuous_days || 0) + 1
    else if (gap === 0) continuous = last.continuous_days || 1
  }
  const row = {
    checkin_id: uuid(),
    user_id: uid(),
    diary_id: diaryId || '',
    checkin_date: today,
    continuous_days: continuous,
    is_makeup: false,
    reward_exp: 10,
    created_at: new Date().toISOString()
  }
  await db.collection('CheckIns').add({ data: row })
  return row
}

/* ---------------- 日记 ---------------- */
async function saveDiary(payload) {
  const now = new Date().toISOString()
  const isDraft = !!payload.is_draft
  const count = wordCount(payload.content)

  if (payload.diary_id) {
    const old = await db.collection('Diaries').where({ diary_id: payload.diary_id }).get()
    const prev = old.data[0]
    await db.collection('Diaries').where({ diary_id: payload.diary_id }).update({
      data: {
        title: payload.title || '',
        content: payload.content || '',
        mood: payload.mood || '',
        weather: payload.weather || '',
        location: payload.location || '',
        category_id: payload.category_id || '',
        diary_date: payload.diary_date || todayStr(),
        word_count: count,
        is_draft: isDraft,
        updated_at: now
      }
    })
    // 草稿改正式 → 补打卡与奖励
    if (prev && prev.is_draft && !isDraft) {
      const r = await afterPublish(payload.diary_id)
      return { diary_id: payload.diary_id, updated: true, unlocked: r.unlocked || [] }
    }
    return { diary_id: payload.diary_id, updated: true, unlocked: [] }
  }

  const id = 'd_' + uuid().slice(0, 16)
  const row = {
    diary_id: id,
    user_id: uid(),
    category_id: payload.category_id || '',
    title: payload.title || '',
    content: payload.content || '',
    content_iv: '',
    mood: payload.mood || '',
    weather: payload.weather || '',
    location: payload.location || '',
    diary_date: payload.diary_date || todayStr(),
    word_count: count,
    is_favorite: false,
    is_draft: isDraft,
    status: 1,
    created_at: now,
    updated_at: ''
  }
  await db.collection('Diaries').add({ data: row })

  if (payload.mediaList && payload.mediaList.length) {
    for (let i = 0; i < payload.mediaList.length; i++) {
      const m = payload.mediaList[i]
      await db.collection('DiaryMedia').add({
        data: {
          media_id: uuid(),
          diary_id: id,
          user_id: uid(),
          file_id: m.fileID || m.path || '',
          media_type: m.type || 'image',
          file_size: m.size || 0,
          duration: m.duration || 0,
          cover_url: m.cover || '',
          sort_order: i,
          created_at: now
        }
      })
    }
  }

  if (!isDraft) {
    const r = await afterPublish(id)
    return { diary_id: id, created: true, unlocked: r.unlocked || [] }
  }
  return { diary_id: id, created: true, unlocked: [] }
}

/** 发布后：打卡 + 宠物奖励 + 分类计数 + 徽章 */
async function afterPublish(diaryId) {
  const checkin = await checkinToday(diaryId)
  const pet = await getPet()
  const expGain = 10
  const hunger = Math.max(0, Math.min(100, (pet.hunger || 0) - 6))
  await db.collection('Pets').where({ pet_id: pet.pet_id }).update({
    data: {
      exp: (pet.exp || 0) + expGain,
      hunger,
      intimacy: Math.min(100, (pet.intimacy || 0) + 3),
      status: hunger < 30 ? 2 : 1
    }
  })
  await db.collection('FeedLogs').add({
    data: {
      feed_id: uuid(),
      pet_id: pet.pet_id,
      user_id: uid(),
      diary_id: diaryId,
      food_id: '',
      feed_type: 'write_diary',
      exp_gain: expGain,
      hunger_after: hunger,
      feed_time: new Date().toISOString()
    }
  })
  const unlocked = await checkBadges()
  return { checkin, expGain, unlocked }
}

async function toggleFavorite(diaryId, value) {
  await db.collection('Diaries').where({ diary_id: diaryId }).update({ data: { is_favorite: !!value } })
}

async function deleteDiary(diaryId) {
  await db.collection('Diaries').where({ diary_id: diaryId }).update({ data: { status: 0 } })
  await db.collection('DiaryMedia').where({ diary_id: diaryId }).remove()
}

/* ---------------- 徽章 ---------------- */
async function getBadgeProgress() {
  const [badges, ownedRes, diaries, checks] = await Promise.all([
    db.collection('Badges').orderBy('sort_order', 'asc').get(),
    db.collection('UserBadges').where({ user_id: uid() }).get(),
    db.collection('Diaries').where({ user_id: uid(), is_draft: false, status: 1 }).get(),
    db.collection('CheckIns').where({ user_id: uid() }).orderBy('checkin_date', 'desc').limit(1).get()
  ])

  const diaryList = diaries.data
  const totalWords = diaryList.reduce((s, d) => s + (d.word_count || 0), 0)
  const favCount = diaryList.filter(d => d.is_favorite).length
  const continuous = checks.data.length ? checks.data[0].continuous_days || 0 : 0

  const owned = {}
  ownedRes.data.forEach(u => { owned[u.badge_id] = u })

  return badges.data.map(b => {
    let cur = 0
    if (b.condition_type === 'diary_count') cur = diaryList.length
    else if (b.condition_type === 'word_count') cur = totalWords
    else if (b.condition_type === 'favorite_count') cur = favCount
    else if (b.condition_type === 'continuous_days') cur = continuous

    const rec = owned[b.badge_id]
    return Object.assign({}, b, {
      current: cur,
      percent: Math.min(100, Math.round((cur / b.condition_value) * 100)),
      unlocked: !!(rec && rec.is_unlocked) || cur >= b.condition_value,
      unlock_time: rec ? rec.unlock_time : ''
    })
  })
}

/** 检查并写入新解锁徽章，返回本次新解锁的列表 */
async function checkBadges() {
  const list = await getBadgeProgress()
  const ownedRes = await db.collection('UserBadges').where({ user_id: uid() }).get()
  const owned = {}
  ownedRes.data.forEach(u => { owned[u.badge_id] = u })

  const fresh = []
  for (const b of list) {
    if (b.unlocked && !owned[b.badge_id]) {
      await db.collection('UserBadges').add({
        data: {
          user_badge_id: uuid(),
          user_id: uid(),
          badge_id: b.badge_id,
          progress: b.current,
          is_unlocked: true,
          unlock_time: new Date().toISOString()
        }
      })
      fresh.push(b)
    } else if (owned[b.badge_id] && owned[b.badge_id].progress !== b.current) {
      await db.collection('UserBadges').where({ user_badge_id: owned[b.badge_id].user_badge_id })
        .update({ data: { progress: b.current } })
    }
  }
  return fresh
}

/* ---------------- 统计 ---------------- */
async function getStats() {
  const [diaries, checks, badges, pet] = await Promise.all([
    db.collection('Diaries').where({ user_id: uid(), status: 1, is_draft: false }).get(),
    db.collection('CheckIns').where({ user_id: uid() }).orderBy('checkin_date', 'desc').limit(1).get(),
    getBadgeProgress(),
    getPet()
  ])
  const list = diaries.data
  const totalWords = list.reduce((s, d) => s + (d.word_count || 0), 0)
  return {
    diaryCount: list.length,
    totalWords,
    continuous: checks.data.length ? checks.data[0].continuous_days || 0 : 0,
    badgeCount: badges.filter(b => b.unlocked).length,
    badgeTotal: badges.length,
    pet
  }
}

module.exports = {
  getPet,
  renamePet,
  feedPet,
  checkinToday,
  latestCheckin,
  saveDiary,
  toggleFavorite,
  deleteDiary,
  getBadgeProgress,
  checkBadges,
  getStats
}
