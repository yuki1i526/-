const { uuid, formatDate, dayDiff } = require('./util')

function dateOffset(days) {
  const d = new Date()
  d.setDate(d.getDate() - days)
  return formatDate(d)
}

/** 首次进入时写入的演示数据：字典表 + 几条示例内容，让界面不是空的 */
function buildSeed(userId) {
  const now = new Date().toISOString()

  const foods = [
    { food_id: 'f001', name: '小鱼干', icon_url: '🐟', exp_value: 5, hunger_value: 20, price: 0, is_active: true },
    { food_id: 'f002', name: '猫罐头', icon_url: '🥫', exp_value: 12, hunger_value: 45, price: 10, is_active: true },
    { food_id: 'f003', name: '奶油蛋糕', icon_url: '🍰', exp_value: 25, hunger_value: 60, price: 25, is_active: true },
    { food_id: 'f004', name: '热牛奶', icon_url: '🥛', exp_value: 8, hunger_value: 30, price: 6, is_active: true },
    { food_id: 'f005', name: '小饼干', icon_url: '🍪', exp_value: 6, hunger_value: 25, price: 4, is_active: true },
    { food_id: 'f006', name: '星星糖', icon_url: '⭐', exp_value: 30, hunger_value: 15, price: 30, is_active: true }
  ]

  const badges = [
    { badge_id: 'b001', name: '初次见面', description: '写下第一篇日记', icon_url: '🌱', condition_type: 'diary_count', condition_value: 1, badge_level: 1, sort_order: 1 },
    { badge_id: 'b002', name: '笔耕不辍', description: '累计写下 10 篇日记', icon_url: '✍️', condition_type: 'diary_count', condition_value: 10, badge_level: 1, sort_order: 2 },
    { badge_id: 'b003', name: '日记达人', description: '累计写下 50 篇日记', icon_url: '📚', condition_type: 'diary_count', condition_value: 50, badge_level: 2, sort_order: 3 },
    { badge_id: 'b004', name: '三日之约', description: '连续记录 3 天', icon_url: '🔥', condition_type: 'continuous_days', condition_value: 3, badge_level: 1, sort_order: 4 },
    { badge_id: 'b005', name: '一周不断更', description: '连续记录 7 天', icon_url: '🌈', condition_type: 'continuous_days', condition_value: 7, badge_level: 2, sort_order: 5 },
    { badge_id: 'b006', name: '月度坚持', description: '连续记录 30 天', icon_url: '👑', condition_type: 'continuous_days', condition_value: 30, badge_level: 3, sort_order: 6 },
    { badge_id: 'b007', name: '万字长跑', description: '累计写下 10000 字', icon_url: '🖋️', condition_type: 'word_count', condition_value: 10000, badge_level: 2, sort_order: 7 },
    { badge_id: 'b008', name: '收藏家', description: '收藏 10 篇日记', icon_url: '💎', condition_type: 'favorite_count', condition_value: 10, badge_level: 2, sort_order: 8 }
  ]

  const categories = [
    { category_id: 'c001', user_id: userId, name: '日常', icon: '🌤', color: '#FFB74D', sort_order: 1, is_default: true, diary_count: 0, created_at: now },
    { category_id: 'c002', user_id: userId, name: '心情', icon: '💭', color: '#BA68C8', sort_order: 2, is_default: false, diary_count: 0, created_at: now },
    { category_id: 'c003', user_id: userId, name: '学习', icon: '📖', color: '#64B5F6', sort_order: 3, is_default: false, diary_count: 0, created_at: now },
    { category_id: 'c004', user_id: userId, name: '旅行', icon: '🧳', color: '#81C784', sort_order: 4, is_default: false, diary_count: 0, created_at: now }
  ]

  const diaries = [
    {
      diary_id: 'd_seed_1', user_id: userId, category_id: 'c001',
      title: '秋天的第一杯热可可',
      content: '下课路上风有点凉，绕去校门口那家小店买了一杯热可可。\n\n老板认得我了，笑着说「还是老样子吧」。捧着杯子往回走的时候，看到路边的银杏已经黄了一半，风一吹就落下来几片，贴在湿漉漉的地面上。\n\n好像每年秋天我都会拍一张银杏，翻回相册看，去年的、前年的，背景里的教学楼一直没变，只有我自己在变。',
      content_iv: '', mood: 'calm', weather: 'cloudy', location: '学校东门',
      diary_date: dateOffset(0), word_count: 142, is_favorite: true, is_draft: false,
      status: 1, created_at: new Date().toISOString(), updated_at: ''
    },
    {
      diary_id: 'd_seed_2', user_id: userId, category_id: 'c003',
      title: '数据库大作业终于跑通了',
      content: '查了一下午的外键报错，最后发现是建表顺序的问题。\n\n本来想放弃直接用 ORM 自动建表，但老师说要看 DDL，只好老老实实一行行对。改完之后在命令行敲下 source 的那一刻，看着十几张表齐刷刷列出来，居然有点感动。\n\n原来我是会因为这种事情高兴的人啊。',
      content_iv: '', mood: 'excited', weather: 'sunny', location: '图书馆四楼',
      diary_date: dateOffset(1), word_count: 118, is_favorite: false, is_draft: false,
      status: 1, created_at: new Date().toISOString(), updated_at: ''
    },
    {
      diary_id: 'd_seed_3', user_id: userId, category_id: 'c002',
      title: '有点累',
      content: '今天什么都不想做，躺在床上刷了两个小时手机，然后开始怪自己浪费时间。\n\n后来想想，可能只是需要休息。写完这篇就去洗澡睡觉了，明天再努力也不迟。',
      content_iv: '', mood: 'tired', weather: 'rain', location: '宿舍',
      diary_date: dateOffset(2), word_count: 76, is_favorite: false, is_draft: false,
      status: 1, created_at: new Date().toISOString(), updated_at: ''
    }
  ]

  const pet = {
    pet_id: 'pet_' + userId,
    user_id: userId,
    pet_name: '团子',
    pet_type: '猫',
    skin_id: 'default',
    level: 3,
    exp: 260,
    hunger: 62,
    intimacy: 45,
    status: 1,
    last_feed_time: '',
    created_at: now
  }

  const countdowns = [
    {
      event_id: 'e001', user_id: userId, title: '期末答辩', event_type: 'exam',
      target_date: dateOffset(-18), repeat_type: 'none', remind_days: 1,
      theme_color: '#FF7A59', is_top: true, status: 1, created_at: now
    },
    {
      event_id: 'e002', user_id: userId, title: '生日', event_type: 'birthday',
      target_date: dateOffset(-45), repeat_type: 'yearly', remind_days: 3,
      theme_color: '#BA68C8', is_top: false, status: 1, created_at: now
    }
  ]

  const capsules = [
    {
      capsule_id: 'cap001', user_id: userId, title: '写给一年后的自己',
      content: '你好呀。写这封信的时候是秋天，我不知道一年后的你在哪里、在做什么。\n\n希望你还保持记录的习惯，希望你还记得那些细碎的、不重要的、但你舍不得忘的事。',
      media_list: '[]', open_time: dateOffset(-365) + ' 09:00', status: 1,
      is_notified: false, created_at: now
    }
  ]

  return { foods, badges, categories, diaries, pet, countdowns, capsules }
}

module.exports = { buildSeed }
