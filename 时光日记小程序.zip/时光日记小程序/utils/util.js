/** 通用工具：日期、字数、ID、字典 */

function pad2(n) {
  return n < 10 ? '0' + n : '' + n
}

/** Date | string → 'YYYY-MM-DD' */
function formatDate(d) {
  if (!d) return ''
  const dt = typeof d === 'string' ? new Date(d.replace(/-/g, '/')) : d
  if (isNaN(dt.getTime())) return String(d).slice(0, 10)
  return dt.getFullYear() + '-' + pad2(dt.getMonth() + 1) + '-' + pad2(dt.getDate())
}

/** Date | string → 'YYYY-MM-DD HH:mm' */
function formatTime(d) {
  const dt = typeof d === 'string' ? new Date(String(d).replace(/-/g, '/')) : d
  if (isNaN(dt.getTime())) return ''
  return formatDate(dt) + ' ' + pad2(dt.getHours()) + ':' + pad2(dt.getMinutes())
}

function todayStr() {
  return formatDate(new Date())
}

/** 两个日期相差天数（a - b），按自然日 */
function dayDiff(a, b) {
  const da = new Date(formatDate(a).replace(/-/g, '/'))
  const db = new Date(formatDate(b).replace(/-/g, '/'))
  return Math.round((da - db) / 86400000)
}

/** 距离某天还有几天（未来为正） */
function daysUntil(target) {
  return dayDiff(target, new Date())
}

function greeting() {
  const h = new Date().getHours()
  if (h < 6) return '夜深了'
  if (h < 11) return '早上好'
  if (h < 14) return '中午好'
  if (h < 18) return '下午好'
  return '晚上好'
}

/** 中文按字符计，英文按单词计，去空白 */
function wordCount(text) {
  if (!text) return 0
  const t = String(text).trim()
  if (!t) return 0
  const cn = (t.match(/[\u4e00-\u9fa5]/g) || []).length
  const en = (t.replace(/[\u4e00-\u9fa5]/g, ' ').match(/[a-zA-Z0-9]+/g) || []).length
  return cn + en
}

function uuid() {
  return 'xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = (Math.random() * 16) | 0
    const v = c === 'x' ? r : (r & 0x3) | 0x8
    return v.toString(16)
  })
}

/** '2026-11-04' → '11月4日 周三' */
function prettyDate(d) {
  const dt = new Date(formatDate(d).replace(/-/g, '/'))
  const week = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][dt.getDay()]
  return (dt.getMonth() + 1) + '月' + dt.getDate() + '日 ' + week
}

/** 相对日期标签 */
function relLabel(d) {
  const diff = dayDiff(todayStr(), d)
  if (diff === 0) return '今天'
  if (diff === 1) return '昨天'
  if (diff === 2) return '前天'
  return prettyDate(d)
}

const MOODS = [
  { key: 'happy', label: '开心', emoji: '😄', color: '#FFB74D' },
  { key: 'calm', label: '平静', emoji: '😌', color: '#81C784' },
  { key: 'tired', label: '疲惫', emoji: '😪', color: '#90A4AE' },
  { key: 'sad', label: '难过', emoji: '😢', color: '#64B5F6' },
  { key: 'angry', label: '生气', emoji: '😤', color: '#E57373' },
  { key: 'excited', label: '兴奋', emoji: '🤩', color: '#BA68C8' }
]

const WEATHERS = [
  { key: 'sunny', label: '晴', emoji: '☀️' },
  { key: 'cloudy', label: '多云', emoji: '⛅' },
  { key: 'rain', label: '雨', emoji: '🌧️' },
  { key: 'snow', label: '雪', emoji: '❄️' },
  { key: 'wind', label: '风', emoji: '🌬️' }
]

function findIn(list, key) {
  return list.filter(i => i.key === key)[0] || null
}
function moodOf(key) {
  return findIn(MOODS, key) || { key: '', label: '', emoji: '📝', color: '#D8CFC7' }
}
function weatherOf(key) {
  return findIn(WEATHERS, key) || { key: '', label: '', emoji: '' }
}

/** 经验 → 等级（每级所需 100 + 20*level） */
function levelOf(exp) {
  let lv = 1
  let left = exp || 0
  let need = 100
  while (left >= need) {
    left -= need
    lv++
    need = 100 + 20 * (lv - 1)
  }
  return { level: lv, cur: left, need: need, percent: Math.min(100, Math.round((left / need) * 100)) }
}

module.exports = {
  pad2,
  formatDate,
  formatTime,
  todayStr,
  dayDiff,
  daysUntil,
  greeting,
  wordCount,
  uuid,
  prettyDate,
  relLabel,
  MOODS,
  WEATHERS,
  moodOf,
  weatherOf,
  levelOf
}
