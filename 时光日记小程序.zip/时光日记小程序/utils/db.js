/**
 * 数据层：一套 API，两种后端。
 *  - 配置了 CLOUD_ENV 且云能力可用 → 走微信云开发数据库
 *  - 否则 → 走本地 Storage（离线演示模式，功能完全可用）
 * 页面只调用 collection('Diaries').where(...).get() 这类接口，不关心底层。
 */

const { uuid } = require('./util')
const { buildSeed } = require('./seed')

// ===== 把云开发环境 ID 填在这里即可切到云端（例如 'timediary-3g8xxxx'）=====
const CLOUD_ENV = ''

const KEY = 'td_coll_'
const UID_KEY = 'td_uid'
const SEED_FLAG = 'td_seeded'
// 字典表永远放本地，避免云端首次初始化时页面空白
const LOCAL_ONLY = ['FoodItems', 'Badges']

let cloudOn = false
let inited = false
let readyPromise = null

/* ---------------- 本地存储读写 ---------------- */
function readAll(name) {
  const raw = wx.getStorageSync(KEY + name)
  if (!raw) return []
  // 返回副本，避免调用方修改到同一次会话里已取出的数据
  return JSON.parse(JSON.stringify(raw))
}
function writeAll(name, list) {
  wx.setStorageSync(KEY + name, list)
}

/* ---------------- 条件匹配 ---------------- */
function matchOne(actual, expect) {
  if (expect && typeof expect === 'object' && !Array.isArray(expect)) {
    if ('$gt' in expect && !(actual > expect.$gt)) return false
    if ('$gte' in expect && !(actual >= expect.$gte)) return false
    if ('$lt' in expect && !(actual < expect.$lt)) return false
    if ('$lte' in expect && !(actual <= expect.$lte)) return false
    if ('$ne' in expect && actual === expect.$ne) return false
    if ('$in' in expect && expect.$in.indexOf(actual) < 0) return false
    if ('$regex' in expect && !new RegExp(expect.$regex, 'i').test(String(actual))) return false
    return true
  }
  return actual === expect
}
function matchDoc(doc, cond) {
  if (!cond) return true
  for (const k in cond) {
    if (!matchOne(doc[k], cond[k])) return false
  }
  return true
}

function toCloudWhere(w) {
  const _ = wx.cloud.database().command
  const out = {}
  for (const k in w) {
    const v = w[k]
    if (v && typeof v === 'object' && !Array.isArray(v)) {
      let cmd = null
      if ('$gt' in v) cmd = _.gt(v.$gt)
      else if ('$gte' in v) cmd = _.gte(v.$gte)
      else if ('$lt' in v) cmd = _.lt(v.$lt)
      else if ('$lte' in v) cmd = _.lte(v.$lte)
      else if ('$ne' in v) cmd = _.neq(v.$ne)
      else if ('$in' in v) cmd = _.in(v.$in)
      else if ('$regex' in v) cmd = wx.cloud.database().RegExp({ regexp: v.$regex, options: 'i' })
      out[k] = cmd || v
    } else {
      out[k] = v
    }
  }
  return out
}

/* ---------------- 查询器 ---------------- */
class Query {
  constructor(name) {
    this.name = name
    this._w = null
    this._orders = []
    this._limit = 0
    this._skip = 0
    this.isLocal = !cloudOn || LOCAL_ONLY.indexOf(name) >= 0
  }

  where(cond) {
    this._w = cond || null
    return this
  }
  orderBy(field, dir) {
    this._orders.push([field, dir === 'desc' ? 'desc' : 'asc'])
    return this
  }
  skip(n) {
    this._skip = n || 0
    return this
  }
  limit(n) {
    this._limit = n || 0
    return this
  }

  async get() {
    if (this.isLocal) {
      let list = readAll(this.name).filter(d => matchDoc(d, this._w))
      if (this._orders.length) {
        list = list.slice().sort((a, b) => {
          for (const [f, d] of this._orders) {
            const av = a[f] === undefined || a[f] === null ? '' : a[f]
            const bv = b[f] === undefined || b[f] === null ? '' : b[f]
            if (av === bv) continue
            const r = av > bv ? 1 : -1
            return d === 'desc' ? -r : r
          }
          return 0
        })
      }
      const start = this._skip || 0
      const end = this._limit ? start + this._limit : undefined
      return { data: list.slice(start, end) }
    }

    const dbx = wx.cloud.database()
    let q = this._w ? dbx.collection(this.name).where(toCloudWhere(this._w)) : dbx.collection(this.name)
    this._orders.forEach(([f, d]) => { q = q.orderBy(f, d) })
    if (this._skip) q = q.skip(this._skip)
    q = q.limit(this._limit || 100)
    const res = await q.get()
    return { data: res.data || [] }
  }

  async count() {
    if (this.isLocal) {
      return readAll(this.name).filter(d => matchDoc(d, this._w)).length
    }
    const dbx = wx.cloud.database()
    let q = this._w ? dbx.collection(this.name).where(toCloudWhere(this._w)) : dbx.collection(this.name)
    const res = await q.count()
    return res.total
  }

  async add({ data }) {
    const doc = Object.assign({}, data)
    if (this.isLocal) {
      if (!doc._id) doc._id = uuid()
      const list = readAll(this.name)
      list.push(doc)
      writeAll(this.name, list)
      return { _id: doc._id }
    }
    const res = await wx.cloud.database().collection(this.name).add({ data: doc })
    return { _id: res._id }
  }

  async update({ data }) {
    if (this.isLocal) {
      const list = readAll(this.name)
      let n = 0
      list.forEach(d => {
        if (matchDoc(d, this._w)) {
          Object.assign(d, data)
          n++
        }
      })
      writeAll(this.name, list)
      return { updated: n }
    }
    const dbx = wx.cloud.database()
    let q = this._w ? dbx.collection(this.name).where(toCloudWhere(this._w)) : dbx.collection(this.name)
    const res = await q.update({ data })
    return { updated: res.stats ? res.stats.updated : 0 }
  }

  async remove() {
    if (this.isLocal) {
      const list = readAll(this.name)
      const kept = list.filter(d => !matchDoc(d, this._w))
      writeAll(this.name, kept)
      return { removed: list.length - kept.length }
    }
    const dbx = wx.cloud.database()
    let q = this._w ? dbx.collection(this.name).where(toCloudWhere(this._w)) : dbx.collection(this.name)
    const res = await q.remove()
    return { removed: res.stats ? res.stats.removed : 0 }
  }
}

/* ---------------- 初始化 ---------------- */
function currentUserId() {
  let id = wx.getStorageSync(UID_KEY)
  if (!id) {
    id = 'u_' + uuid().slice(0, 12)
    wx.setStorageSync(UID_KEY, id)
  }
  return id
}

function seedLocal() {
  const uid = currentUserId()
  const s = buildSeed(uid)
  if (!readAll('FoodItems').length) writeAll('FoodItems', s.foods)
  if (!readAll('Badges').length) writeAll('Badges', s.badges)
  if (!readAll('Categories').length) writeAll('Categories', s.categories)
  if (!readAll('Diaries').length) writeAll('Diaries', s.diaries)
  if (!readAll('Pets').length) writeAll('Pets', [s.pet])
  if (!readAll('CountdownEvents').length) writeAll('CountdownEvents', s.countdowns)
  if (!readAll('TimeCapsules').length) writeAll('TimeCapsules', s.capsules)
  wx.setStorageSync(SEED_FLAG, 1)
}

async function seedCloud() {
  const uid = currentUserId()
  const s = buildSeed(uid)
  const dbx = wx.cloud.database()
  try {
    const d = await dbx.collection('Diaries').where({ user_id: uid }).count()
    if (d.total > 0) return
    const push = async (name, arr) => {
      for (let i = 0; i < arr.length; i++) {
        await dbx.collection(name).add({ data: arr[i] })
      }
    }
    await push('Categories', s.categories)
    await push('Diaries', s.diaries)
    await push('Pets', [s.pet])
    await push('CountdownEvents', s.countdowns)
    await push('TimeCapsules', s.capsules)
  } catch (e) {
    console.warn('[db] 云端种子数据写入失败，请在云开发控制台检查集合权限', e)
  }
}

function init() {
  if (inited) return readyPromise
  inited = true
  if (CLOUD_ENV && wx.cloud) {
    try {
      wx.cloud.init({ env: CLOUD_ENV, traceUser: true })
      cloudOn = true
    } catch (e) {
      cloudOn = false
    }
  }
  seedLocal()
  readyPromise = cloudOn ? seedCloud() : Promise.resolve()
  return readyPromise
}

function ready() {
  if (!readyPromise) return Promise.resolve(init())
  return readyPromise
}

function useCloud() {
  return cloudOn
}

/** 清空全部演示数据并重建（设置页用） */
function resetAll() {
  const names = ['Users', 'Categories', 'Diaries', 'DiaryMedia', 'Pets', 'FeedLogs',
    'FoodItems', 'Badges', 'UserBadges', 'CheckIns', 'TimeCapsules',
    'CountdownEvents', 'RandomDecisions', 'AIReports', 'Notifications']
  names.forEach(n => wx.removeStorageSync(KEY + n))
  wx.removeStorageSync(SEED_FLAG)
  seedLocal()
}

/** 'YYYY-MM-DD' 序列化辅助，云端 datetime 存储用 */
function nowISO() {
  return new Date().toISOString()
}

module.exports = {
  init,
  ready,
  useCloud,
  currentUserId,
  collection: name => new Query(name),
  uid: uuid,
  resetAll,
  nowISO,
  CLOUD_ENV
}
